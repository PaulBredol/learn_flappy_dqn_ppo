# PPO V2 gegen Double DQN + PER V12

Vorhandene Auswertungen auf jeweils denselben 20 Seeds 42–61. Kein neues Training.

| Bester Checkpoint nach Durchschnitt | PPO V2 | DQN V12 |
|---|---:|---:|
| Schritte | 900000 | 1350000 |
| Durchschnitt | 382.9 | 296.65 |
| Median | 302.5 | 231.5 |
| Minimum | 37 | 13 |
| Maximum | 1195 | 1091 |
| Mittlerer Reward | 3950.88 | 3054.86 |
| Mittlere Dauer, Sekunden bei 30 FPS | 482.36 | 374.01 |

## Vergleich gleicher Trainingsstände

| Schritte | PPO Ø | DQN Ø | PPO >=10 | DQN >=10 |
|---|---:|---:|---:|---:|
| 150000 | 52.7 | 0.0 | 15/20 | 0/20 |
| 300000 | 69.75 | 0.0 | 17/20 | 0/20 |
| 450000 | 78.95 | 0.0 | 20/20 | 0/20 |
| 600000 | 244.25 | 7.1 | 18/20 | 6/20 |
| 750000 | 373.45 | 53.05 | 20/20 | 17/20 |
| 900000 | 382.9 | 93.8 | 20/20 | 19/20 |
| 1050000 | 300.3 | 54.45 | 20/20 | 17/20 |
| 1200000 | 294.25 | 130.9 | 20/20 | 17/20 |
| 1350000 | 224.85 | 296.65 | 18/20 | 20/20 |
| 1500000 | 298.6 | 175.5 | 18/20 | 18/20 |

## Code und Einordnung

- AST-Vergleich: Reward-Wrapper, make_flappy_env und Berechnung der 15 Zustandswerte identisch. Acht DummyVecEnv-Instanzen, Batch 256, gamma 0,995 und Reward-Normalisierung gemeinsam. Keine zusätzliche Beobachtungsnormalisierung.
- PPO: Actor und Critic je [128,128], Standardaktivierung Tanh. DQN: Q-Netz [128,128], ReLU, separates Target-Netz. Nicht identische trainierbare Architektur.
- PPO Lernrate 0,0003 bis 0,00001; DQN 0,00005 bis 0,00001. PPO GAE 0,95, Rollout4096, zehn Epochen, Entropie0,01, Policy-Clipping0,2 bis0,1. DQN Ein-Schritt-Targets, PER, epsilon-greedy und acht Updates pro32 Übergänge.
- Gradientennormgrenze PPO0,5, DQN10; nicht mit Policy-Clipping verwechseln.
- Finale Modellmetadaten: PPO1.503.232 Schritte, DQN1.500.000. PPO beendet volle Rollouts, Mehrbudget etwa0,22%. In config steht abgerundet updates366, tatsächlich367 Rollouts.
- Gleiche Softwareversionen: SB3 2.9.0, Torch2.14.0+cpu, Gymnasium1.3.0, NumPy2.5.3, Python3.13.15. Keine GPU in beiden gespeicherten Systemberichten.
- PPO _n_updates3670 zählt Epochen, DQN373752 zählt Gradientenupdates. Bei PPO16 Minibatches pro Epoche ergeben sich58720 Optimizer-Schritte. Werte nicht direkt als gleiche Updateart vergleichen; tatsächliche Trainingszeit damit nicht bestimmt.
- PPO prüft alle150k, DQN alle50k; einschließlich Endmodell11 bzw31 Kandidaten. Bestenauswahl daher verschieden umfangreich. PPO gewinnt dennoch9 von10 gemeinsamen periodischen Vergleichspunkten, DQN bei1,35Mio.
- Beide schwanken: PPO382,9 bei900k fällt auf224,85 bei1350k. DQN296,65 bei1350k fällt auf110,6 bei1400k. Höheres spätes PPO-Leistungsniveau belegt keine allgemeine Stabilitätsgarantie.
- Finale Modelle: PPO Ø345,55, Median199, >=10 in19/20; DQN Ø170,65, Median136, >=10 in18/20.
- PPO-Rekord final_model/Seed45:1774 Röhren,66869 Schritte,37min9s bei30FPS. DQN1350k/Seed55:1091 Röhren,41141 Schritte,22min51s. Die genannten45Minuten sind in diesen Daten nicht belegt.
- PPO ohne Episodenlimit, DQN100000 Schritte; alle Episoden kürzer, keine Trunkierungen. Kein gemessener Vorteil durch das fehlende Limit.
- PPO bestes Video wählt Einzelflug über alle Modelle; DQN wählt zuerst nach bestem Durchschnitt. Haupttabelle vergleicht einheitlich nach Durchschnitt ausgewählte Modelle.
- Ein Trainingsseed pro Verfahren. Dieselben20 Seeds dienten auch zur Modellauswahl: kein unabhängiger abschließender Test. Ergebnis gilt für diese Konfigurationen; kein Beweis einer allgemeinen PPO-Überlegenheit oder einer isolierten Ursache.

## Quellen

- outputs/V2_DIRECT_STATE_PPO_UNLIMITED_20260925T103842Z_4b8e28ab: config.json, evaluation.json, checkpoints/final_model.zip (nur JSON und system_info.txt gelesen).
- outputs/V12_DIRECT_STATE_DOUBLE_DQN_PER_PPO_STYLE_20260929T132927Z_7137df05: config.json, evaluation.json, checkpoints/final_model.zip (nur JSON und system_info.txt gelesen).
- train_flappy_ppo_v2.py und train_flappy_dqn_v12.py sowie Algorithmusmodule und installierter SB3-Code.
- Trainingscode und Modelle nicht verändert.
